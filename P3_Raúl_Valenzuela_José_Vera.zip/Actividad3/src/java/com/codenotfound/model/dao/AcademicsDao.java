package com.codenotfound.model.dao;

import java.util.List;

import com.codenotfound.model.Academics;

public interface AcademicsDao{
    public List<Academics> findAll();
}
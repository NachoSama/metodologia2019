# app-mvc
Aplicación Java que utiliza el Patrón MVC, material para docencia

referencia en: https://codenotfound.com/jsf-primefaces-example.html

Instalar Maven para compilar: https://platzi.com/tutoriales/1236-java-avanzado/298-instalar-maven-desde-la-terminal-en-linux-ubuntu-1404/

iniciar desde linea de comandos con -> mvn spring-boot:run

